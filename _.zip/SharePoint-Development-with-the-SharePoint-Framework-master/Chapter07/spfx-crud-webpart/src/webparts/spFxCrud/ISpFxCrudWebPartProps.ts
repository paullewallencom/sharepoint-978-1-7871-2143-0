export interface ISpFxCrudWebPartProps {
  description: string;
}
