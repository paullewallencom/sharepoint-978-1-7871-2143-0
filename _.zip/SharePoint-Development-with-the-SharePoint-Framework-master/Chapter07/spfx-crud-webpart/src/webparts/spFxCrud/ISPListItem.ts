export interface ISPListItem {
    Id: number;
    Title: string;
}