export interface ISPList {
    Title: string;
    Id: string;
    LastItemUserModifiedDate: string;
    ImageUrl: string;
}
