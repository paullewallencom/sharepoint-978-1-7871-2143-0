/// <reference types="mocha" />

import { assert } from 'chai';

describe('SpFxCrudWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
