declare interface IHelloListitemsStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'helloListitemsStrings' {
  const strings: IHelloListitemsStrings;
  export = strings;
}
