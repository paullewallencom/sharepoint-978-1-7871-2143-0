export interface ISPListItem {
    Id: number;
    Title: string;
    Info: string;
}