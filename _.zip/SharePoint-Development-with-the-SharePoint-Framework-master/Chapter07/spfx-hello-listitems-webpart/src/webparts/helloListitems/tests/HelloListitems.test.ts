/// <reference types="mocha" />

import { assert } from 'chai';

describe('HelloListitemsWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
