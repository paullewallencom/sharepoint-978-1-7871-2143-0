export interface IHelloListitemsWebPartProps {
  description: string;
}
