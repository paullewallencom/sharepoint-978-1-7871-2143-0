export interface IHelloCustomPropertyPaneFieldWebPartProps {
  description: string;
  password: string;
}
