declare interface IHelloCustomPropertyPaneFieldStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'helloCustomPropertyPaneFieldStrings' {
  const strings: IHelloCustomPropertyPaneFieldStrings;
  export = strings;
}
