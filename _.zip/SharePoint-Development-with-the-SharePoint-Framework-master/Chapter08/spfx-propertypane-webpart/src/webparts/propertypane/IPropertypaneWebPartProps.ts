export interface IPropertypaneWebPartProps {
  description: string;
  customField: string;
}
