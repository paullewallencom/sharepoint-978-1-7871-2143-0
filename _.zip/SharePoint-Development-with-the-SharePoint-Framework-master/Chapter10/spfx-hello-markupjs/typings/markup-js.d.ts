declare module "Mark" {
 function up(context: any, template: string): string
}