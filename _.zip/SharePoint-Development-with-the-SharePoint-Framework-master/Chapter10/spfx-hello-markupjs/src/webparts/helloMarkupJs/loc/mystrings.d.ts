declare interface IHelloMarkupJsStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'helloMarkupJsStrings' {
  const strings: IHelloMarkupJsStrings;
  export = strings;
}
