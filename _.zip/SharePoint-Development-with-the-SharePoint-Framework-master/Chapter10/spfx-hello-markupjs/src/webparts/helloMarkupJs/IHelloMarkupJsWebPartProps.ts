export interface IHelloMarkupJsWebPartProps {
  description: string;
}
