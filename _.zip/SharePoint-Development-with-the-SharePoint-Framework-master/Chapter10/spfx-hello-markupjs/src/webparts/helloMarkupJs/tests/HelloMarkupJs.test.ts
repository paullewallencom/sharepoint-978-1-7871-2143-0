/// <reference types="mocha" />

import { assert } from 'chai';

describe('HelloMarkupJsWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
