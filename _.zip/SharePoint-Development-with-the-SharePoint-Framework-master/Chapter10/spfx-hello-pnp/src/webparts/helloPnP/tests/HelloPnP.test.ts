/// <reference types="mocha" />

import { assert } from 'chai';

describe('HelloPnPWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
