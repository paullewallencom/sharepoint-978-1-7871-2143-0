export interface IHelloPnPWebPartProps {
  description: string;
}
