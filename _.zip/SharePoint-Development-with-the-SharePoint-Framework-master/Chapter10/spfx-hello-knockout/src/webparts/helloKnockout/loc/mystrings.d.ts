declare interface IHelloKnockoutStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'helloKnockoutStrings' {
  const strings: IHelloKnockoutStrings;
  export = strings;
}
