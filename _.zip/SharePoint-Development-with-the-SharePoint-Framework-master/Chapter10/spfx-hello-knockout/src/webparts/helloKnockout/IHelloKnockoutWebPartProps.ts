export interface IHelloKnockoutWebPartProps {
  description: string;
}
