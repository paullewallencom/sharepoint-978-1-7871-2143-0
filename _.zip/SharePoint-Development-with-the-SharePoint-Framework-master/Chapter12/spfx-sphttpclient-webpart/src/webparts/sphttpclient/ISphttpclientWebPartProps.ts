export interface ISphttpclientWebPartProps {
  description: string;
}
