declare interface ISphttpclientStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'sphttpclientStrings' {
  const strings: ISphttpclientStrings;
  export = strings;
}
