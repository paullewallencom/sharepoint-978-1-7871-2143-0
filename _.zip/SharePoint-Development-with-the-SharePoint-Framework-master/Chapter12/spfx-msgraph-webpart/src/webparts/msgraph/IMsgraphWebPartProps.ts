export interface IMsgraphWebPartProps {
  description: string;
}
