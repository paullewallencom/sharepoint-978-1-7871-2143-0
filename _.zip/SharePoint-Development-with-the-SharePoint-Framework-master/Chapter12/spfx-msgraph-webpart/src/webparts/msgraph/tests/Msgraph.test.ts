/// <reference types="mocha" />

import { assert } from 'chai';

describe('MsgraphWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
