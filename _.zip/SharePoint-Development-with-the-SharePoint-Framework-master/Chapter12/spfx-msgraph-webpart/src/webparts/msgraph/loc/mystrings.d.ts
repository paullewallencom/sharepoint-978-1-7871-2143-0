declare interface IMsgraphStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'msgraphStrings' {
  const strings: IMsgraphStrings;
  export = strings;
}
