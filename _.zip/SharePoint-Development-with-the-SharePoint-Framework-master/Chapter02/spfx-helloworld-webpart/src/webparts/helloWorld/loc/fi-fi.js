define([], function() {
  return {
    "PropertyPaneDescription": "Kuvaus",
    "BasicGroupName": "Ryhmän nimi",
    "DescriptionFieldLabel": "Kuvaus kenttä"
  }
});
