/// <reference types="mocha" />

import { assert } from 'chai';

describe('FeedbackWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
