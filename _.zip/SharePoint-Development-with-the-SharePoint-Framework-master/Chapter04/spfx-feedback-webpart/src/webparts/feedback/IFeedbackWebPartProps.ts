export interface IFeedbackWebPartProps {
  hintText: string;
}
