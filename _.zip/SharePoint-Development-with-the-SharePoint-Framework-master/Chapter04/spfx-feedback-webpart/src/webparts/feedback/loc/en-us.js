define([], function() {
  return {
    "PropertyPaneDescription": "Modify web part properties",
    "BasicGroupName": "Fields",
    "HintTextFieldLabel": "Hint Text"
  }
});