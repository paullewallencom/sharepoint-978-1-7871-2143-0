export interface ITodoItemState {
  itemId?: number;
  itemTitle?: string;
  itemDone?: boolean;
  showPanel?: boolean;
}