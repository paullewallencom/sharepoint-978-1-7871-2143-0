export interface ITodoItemProps {
  itemId: number;
  itemTitle: string;
  itemDone: boolean;
  edit: any;
  delete: any;
}