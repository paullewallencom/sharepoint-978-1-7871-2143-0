import TodoClient from '../TodoClient';
export interface IReactTodoProps {
  description: string;
  todoClient: TodoClient;
}
