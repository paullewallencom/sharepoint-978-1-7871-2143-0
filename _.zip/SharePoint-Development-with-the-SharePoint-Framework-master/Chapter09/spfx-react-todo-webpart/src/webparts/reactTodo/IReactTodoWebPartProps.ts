export interface IReactTodoWebPartProps {
  description: string;
}
