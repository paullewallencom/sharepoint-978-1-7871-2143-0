export interface ITodoItem {
    Id: number;
    Title: string;
    Done: boolean;
}
